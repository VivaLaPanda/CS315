#ifndef _isSorted_hpp
#define _isSorted_hpp

#include<iostream>
#include<cstdlib>

extern bool isSortedIterative(int list[], int n);
extern bool isSortedRecursive(int list[], int n);

#endif