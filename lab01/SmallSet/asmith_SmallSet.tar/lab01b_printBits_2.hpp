typedef unsigned long bit_t;

void dumpBits0(bit_t v, int digitsPrinted=0);
void dumpBits(bit_t v);
